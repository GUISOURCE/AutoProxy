import aiohttp
import asyncio
import logging
import os
import platform
import subprocess
import sys
import psutil
import signal
from bs4 import BeautifulSoup
import json

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("autoproxylogbyweaser.txt"),
        logging.StreamHandler()
    ]
)

PROXY_SOURCES_FILE = "proxy_sources.json"
PROXY_TYPES = ['http', 'https', 'socks4', 'socks5']
TEST_SITES = [
    "http://httpbin.org/ip",
    "http://ipinfo.io/ip",
    "http://api.ipify.org",
    "https://api.myip.com",
]
TIMEOUT = aiohttp.ClientTimeout(total=5)
CHECK_INTERVAL = 60
NO_PROXY_SITE = ""

def load_proxy_sources():
    if os.path.exists(PROXY_SOURCES_FILE):
        with open(PROXY_SOURCES_FILE, "r") as f:
            return json.load(f)
    return [
        "https://www.sslproxies.org/",
        "https://free-proxy-list.net/",
        "https://us-proxy.org/",
        "https://www.proxy-list.download/HTTP",
        "https://www.proxyscrape.com/free-proxy-list",
    ]

def save_proxy_sources(sources):
    with open(PROXY_SOURCES_FILE, "w") as f:
        json.dump(sources, f)

async def fetch_proxies(session, url):
    try:
        async with session.get(url, timeout=TIMEOUT) as response:
            if response.status != 200:
                logging.warning(f"Ошибка при запросе {url}: статус {response.status}")
                return []
            content = await response.text()
            return parse_proxies(content, url)
    except Exception as e:
        logging.error(f"Ошибка при получении прокси с {url}: {e}")
        return []

def parse_proxies(html, url):
    soup = BeautifulSoup(html, 'html.parser')
    proxies = []
    if "sslproxies.org" in url:
        table = soup.find("table", class_="table")
        for row in table.tbody.find_all('tr'):
            columns = row.find_all('td')
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
    elif "free-proxy-list.net" in url:
        table = soup.find("table", id="list")
        for row in table.tbody.find_all('tr'):
            columns = row.find_all('td')
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
    elif "us-proxy.org" in url:
        table = soup.find("table", class_="table").find('tbody')
        for row in table.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
    elif "proxy-list.download" in url:
        for row in soup.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
    elif "proxyscrape.com" in url:
        table = soup.find("table")
        for row in table.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
    return list(set(proxies))

async def get_current_ip(session):
    try:
        async with session.get("http://httpbin.org/ip", timeout=TIMEOUT) as response:
            if response.status == 200:
                data = await response.json()
                return data.get("origin")
    except Exception as e:
        logging.error(f"Ошибка при получении IP: {e}")
    return None

async def is_proxy_working(proxy):
    try:
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            original_ip = await get_current_ip(session)
            if not original_ip:
                return False
            for test_site in TEST_SITES:
                async with session.get(test_site, proxy=proxy, timeout=TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.text()
                        logging.info(f"Прокси {proxy} работает на {test_site}.")
                        if original_ip not in data:
                            return True
    except Exception as e:
        logging.debug(f"Ошибка при проверке прокси {proxy}: {e}")
    return False

async def find_working_proxies(proxies):
    tasks = [is_proxy_working(proxy) for proxy in proxies]
    results = await asyncio.gather(*tasks)
    working_proxies = [proxy for proxy, result in zip(proxies, results) if result]
    return working_proxies

def clear_dns_cache():
    try:
        if platform.system() == "Windows":
            subprocess.run(["ipconfig", "/flushdns"], check=True)
            logging.info("Кэш DNS очищен.")
        elif platform.system() == "Darwin":
            subprocess.run(["sudo", "dscacheutil", "-flushcache"], check=True)
            subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"], check=True)
            logging.info("Кэш DNS очищен.")
        elif platform.system() == "Linux":
            subprocess.run(["sudo", "systemd-resolve", "--flush-caches"], check=True)
            logging.info("Кэш DNS очищен.")
    except Exception as e:
        logging.error(f"Ошибка при очистке кэша DNS: {e}")

def set_system_proxy(proxy):
    ip, port = proxy.split("://")[1].split(":")
    system = platform.system()
    try:
        if system == "Windows":
            import winreg
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            key = winreg.OpenKey(registry, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings", 0, winreg.KEY_WRITE)
            winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, f"{ip}:{port}")
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(key, "ProxyOverride", 0, winreg.REG_SZ, f"<local>;{NO_PROXY_SITE}")
            winreg.CloseKey(key)
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в Windows.")
        elif system == "Darwin":
            subprocess.run(["networksetup", "-setwebproxy", "Wi-Fi", ip, port], check=True)
            subprocess.run(["networksetup", "-setsecurewebproxy", "Wi-Fi", ip, port], check=True)
            subprocess.run(["networksetup", "-setproxybypassdomains", "Wi-Fi", NO_PROXY_SITE], check=True)
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в macOS.")
        elif system == "Linux":
            os.environ["http_proxy"] = f"{proxy}"
            os.environ["https_proxy"] = f"{proxy}"
            os.environ["no_proxy"] = NO_PROXY_SITE
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в Linux.")
    except Exception as e:
        logging.error(f"Ошибка при настройке прокси: {e}")

def launch_chrome_with_proxy(proxy):
    ip, port = proxy.split("://")[1].split(":")
    chrome_path = {
        "Windows": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
        "Darwin": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "Linux": "/usr/bin/google-chrome"
    }.get(platform.system())
    if not chrome_path or not os.path.exists(chrome_path):
        logging.error("Google Chrome не найден.")
        return
    try:
        subprocess.Popen([chrome_path, f"--proxy-server={proxy}", f"--proxy-bypass-list={NO_PROXY_SITE}"])
        logging.info(f"Google Chrome запущен с прокси {proxy}.")
    except Exception as e:
        logging.error(f"Ошибка при запуске Google Chrome: {e}")

def disable_system_proxy():
    system = platform.system()
    try:
        if system == "Windows":
            import winreg
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            key = winreg.OpenKey(registry, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings", 0, winreg.KEY_WRITE)
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            logging.info("Прокси отключен в Windows.")
        elif system == "Darwin":
            subprocess.run(["networksetup", "-setwebproxystate", "Wi-Fi", "off"], check=True)
            subprocess.run(["networksetup", "-setsecurewebproxystate", "Wi-Fi", "off"], check=True)
            logging.info("Прокси отключен в macOS.")
        elif system == "Linux":
            os.environ.pop("http_proxy", None)
            os.environ.pop("https_proxy", None)
            os.environ.pop("no_proxy", None)
            logging.info("Прокси отключен в Linux.")
    except Exception as e:
        logging.error(f"Ошибка при отключении прокси: {e}")

def signal_handler(sig, frame):
    logging.info("Завершение программы...")
    disable_system_proxy()
    sys.exit(0)

async def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    proxy_sources = load_proxy_sources()
    while True:
        logging.info("Поиск рабочих прокси...")
        async with aiohttp.ClientSession() as session:
            tasks = [fetch_proxies(session, url) for url in proxy_sources]
            results = await asyncio.gather(*tasks)
            proxies = list(set(proxy for sublist in results for proxy in sublist))
            if proxies:
                logging.info(f"Найдено {len(proxies)} прокси.")
                working_proxies = await find_working_proxies(proxies)
                if working_proxies:
                    for proxy in working_proxies:
                        logging.info(f"Найден рабочий прокси: {proxy}")
                        set_system_proxy(proxy)
                        await asyncio.sleep(CHECK_INTERVAL)
                else:
                    logging.warning("Рабочий прокси не найден. Повторная попытка через 1 минуту...")
            else:
                logging.error("Не удалось получить список прокси. Повторная попытка через 1 минуту...")
            await asyncio.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        logging.error(f"Критическая ошибка: {e}")
        disable_system_proxy()
        sys.exit(1)