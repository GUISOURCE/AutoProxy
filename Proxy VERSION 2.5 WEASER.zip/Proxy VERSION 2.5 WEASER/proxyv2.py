import aiohttp
import asyncio
import logging
import os
import platform
import subprocess
import sys
import json
from bs4 import BeautifulSoup
import time
import signal
import random
from fake_useragent import UserAgent
import tkinter as tk
from tkinter import ttk, messagebox
import multiprocessing
from aiohttp_socks import ProxyConnector  # Установить: pip install aiohttp-socks
from urllib.parse import urlparse
import winreg  # Для Windows

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("autoproxylogbyweaser.txt"), logging.StreamHandler()]
)

PROXY_SOURCES_FILE = "proxy_sources.json"
TEST_SITES = ["http://httpbin.org/ip", "http://ipinfo.io/ip", "http://api.ipify.org", "https://api.myip.com"]
TIMEOUT = aiohttp.ClientTimeout(total=5)
CHECK_INTERVAL = 60
NO_PROXY_SITE = ""
ROTATION_INTERVAL = 300  # Интервал ротации прокси (в секундах)

working_proxies = []
blacklisted_proxies = set()  # Черный список
semaphore = asyncio.Semaphore(multiprocessing.cpu_count() * 10)  # Динамический Semaphore
ua = UserAgent()
stats = {"total": 0, "working": 0, "avg_speed": 0.0}  # Статистика


# Загрузка источников прокси
def load_proxy_sources():
    if os.path.exists(PROXY_SOURCES_FILE):
        with open(PROXY_SOURCES_FILE, "r") as f:
            return json.load(f)
    return [
        "https://www.sslproxies.org/",
        "https://free-proxy-list.net/",
        "https://us-proxy.org/",
        "https://www.proxy-list.download/HTTP",
        "https://www.proxyscrape.com/free-proxy-list",
    ]


# Сохранение источников прокси
def save_proxy_sources(sources):
    with open(PROXY_SOURCES_FILE, "w") as f:
        json.dump(sources, f)


# Валидация URL
def is_valid_url(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc]) and result.scheme in ["http", "https"]
    except ValueError:
        return False


# Валидация прокси
def is_valid_proxy(proxy):
    try:
        protocol, rest = proxy.split("://", 1)
        ip, port = rest.split(":")
        return protocol in ["http", "https", "socks4", "socks5"] and ip and port.isdigit()
    except ValueError:
        return False


# Получение списка прокси с URL с ретрай-механизмом
async def fetch_proxies(session, url, retries=3, backoff_factor=2):
    if not is_valid_url(url):
        logging.error(f"Некорректный URL: {url}")
        return []
    for attempt in range(retries):
        try:
            async with session.get(url, timeout=TIMEOUT) as response:
                if response.status != 200:
                    logging.warning(f"Ошибка при запросе {url}: статус {response.status}")
                    return []
                content = await response.text()
                return parse_proxies(content, url)
        except Exception as e:
            if attempt < retries - 1:
                delay = backoff_factor ** attempt
                logging.warning(f"Ошибка при получении {url}: {e}. Повтор через {delay} сек.")
                await asyncio.sleep(delay)
            else:
                logging.error(f"Не удалось получить прокси с {url} после {retries} попыток: {e}")
                return []


# Парсинг прокси из HTML
def parse_proxies(html, url):
    soup = BeautifulSoup(html, 'html.parser')
    proxies = []

    if "sslproxies.org" in url:
        table = soup.find("table", class_="table")
        for row in table.tbody.find_all('tr'):
            columns = row.find_all('td')
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
                proxies.append(f"https://{ip}:{port}")

    elif "free-proxy-list.net" in url:
        table = soup.find("table", id="proxylisttable")
        for row in table.tbody.find_all('tr'):
            columns = row.find_all('td')
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                https = columns[6].text.strip() == "yes"
                protocol = "https" if https else "http"
                proxies.append(f"{protocol}://{ip}:{port}")

    elif "us-proxy.org" in url:
        table = soup.find("table", class_="table").find('tbody')
        for row in table.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
                proxies.append(f"https://{ip}:{port}")

    elif "proxy-list.download" in url:
        for row in soup.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
                proxies.append(f"https://{ip}:{port}")

    elif "proxyscrape.com" in url:
        table = soup.find("table")
        for row in table.find_all("tr"):
            columns = row.find_all("td")
            if len(columns) >= 2:
                ip = columns[0].text.strip()
                port = columns[1].text.strip()
                proxies.append(f"http://{ip}:{port}")
                proxies.append(f"https://{ip}:{port}")

    return list(set(proxies))


# Проверка HTTP/HTTPS-прокси
async def is_http_proxy_working(proxy):
    if proxy in blacklisted_proxies or not is_valid_proxy(proxy):
        return False
    try:
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.ClientSession(connector=connector, headers={"User-Agent": ua.random}) as session:
            original_ip = await get_current_ip(session)
            if not original_ip:
                return False
            for test_site in TEST_SITES:
                async with session.get(test_site, proxy=proxy, timeout=TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.text()
                        logging.info(f"Прокси {proxy} работает на {test_site}.")
                        if original_ip not in data:
                            return True
    except Exception as e:
        logging.debug(f"Ошибка при проверке прокси {proxy}: {e}")
        blacklisted_proxies.add(proxy)
    return False


# Проверка SOCKS4/SOCKS5-прокси
async def is_socks_proxy_working(proxy):
    if proxy in blacklisted_proxies or not is_valid_proxy(proxy):
        return False
    try:
        connector = ProxyConnector.from_url(proxy)
        async with aiohttp.ClientSession(connector=connector, headers={"User-Agent": ua.random}) as session:
            async with session.get("http://httpbin.org/ip", timeout=TIMEOUT) as response:
                if response.status == 200:
                    return True
    except Exception:
        blacklisted_proxies.add(proxy)
        return False


# Поиск рабочих прокси
async def find_working_proxies(proxies):
    tasks = []
    for proxy in proxies:
        if proxy.startswith("socks"):
            tasks.append(is_socks_proxy_working(proxy))
        else:
            tasks.append(is_http_proxy_working(proxy))
    results = await asyncio.gather(*tasks)
    working_proxies = [proxy for proxy, result in zip(proxies, results) if result]
    return working_proxies


# Периодическая проверка прокси и обновление статистики
async def periodic_proxy_check():
    global working_proxies, stats
    while True:
        if working_proxies:
            logging.info("Проверка рабочих прокси на скорость...")
            speed_tasks = [check_proxy_speed(proxy) for proxy in working_proxies]
            speeds = await asyncio.gather(*speed_tasks)
            stats["total"] = len(working_proxies)
            stats["working"] = sum(1 for s in speeds if s < float('inf'))
            stats["avg_speed"] = sum(s for s in speeds if s < float('inf')) / max(stats["working"], 1)
            logging.info(
                f"Статистика: Всего: {stats['total']}, Рабочих: {stats['working']}, Средняя скорость: {stats['avg_speed']:.2f} сек")
            with open("proxy_stats.txt", "a") as f:
                f.write(
                    f"Статистика: Всего: {stats['total']}, Рабочих: {stats['working']}, Средняя скорость: {stats['avg_speed']:.2f} сек\n")
            for proxy, speed in zip(working_proxies, speeds):
                if speed < 5:
                    logging.info(f"Прокси {proxy} работает быстрее 5 секунд: {speed:.2f} секунд.")
                else:
                    logging.warning(f"Прокси {proxy} работает медленно: {speed:.2f} секунд.")
        await asyncio.sleep(CHECK_INTERVAL)


# Проверка скорости прокси
async def check_proxy_speed(proxy):
    start_time = time.time()
    try:
        connector = aiohttp.TCPConnector(ssl=False) if not proxy.startswith("socks") else ProxyConnector.from_url(proxy)
        async with semaphore:
            async with aiohttp.ClientSession(connector=connector, headers={"User-Agent": ua.random}) as session:
                async with session.get("http://httpbin.org/ip", proxy=proxy, timeout=TIMEOUT) as response:
                    if response.status == 200:
                        elapsed_time = time.time() - start_time
                        logging.info(f"Прокси {proxy} проверен: {elapsed_time:.2f} секунд.")
                        return elapsed_time
    except Exception as e:
        logging.error(f"Ошибка при проверке скорости прокси {proxy}: {e}")
    return float('inf')


# Проверка анонимности прокси
async def check_proxy_anonymity(proxy):
    try:
        connector = aiohttp.TCPConnector(ssl=False) if not proxy.startswith("socks") else ProxyConnector.from_url(proxy)
        async with aiohttp.ClientSession(connector=connector, headers={"User-Agent": ua.random}) as session:
            async with session.get("http://ip-api.com/json", proxy=proxy, timeout=TIMEOUT) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("query") == data.get("as"):
                        return "Transparent"
                    elif data.get("country") != "Unknown":
                        return "Anonymous"
                    else:
                        return "Elite"
    except Exception:
        return "Unknown"


# Логирование статистики прокси
def log_proxy_stats(proxy, speed, anonymity):
    with open("proxy_stats.txt", "a") as f:
        f.write(f"{proxy} - Speed: {speed:.2f}s, Anonymity: {anonymity}\n")


# Ротация прокси
def rotate_proxy(proxies):
    return random.choice(proxies) if proxies else None


# Автоматическая ротация прокси
async def rotate_proxies_periodically():
    global working_proxies
    while True:
        if working_proxies:
            selected_proxy = rotate_proxy(working_proxies)
            set_system_proxy(selected_proxy)
            logging.info(f"Ротация: выбран прокси {selected_proxy}")
        await asyncio.sleep(ROTATION_INTERVAL)


# Получение текущего IP
async def get_current_ip(session):
    try:
        async with session.get("http://httpbin.org/ip", timeout=TIMEOUT) as response:
            if response.status == 200:
                data = await response.json()
                return data.get("origin")
    except Exception as e:
        logging.error(f"Ошибка при получении IP: {e}")
    return None


# Очистка DNS-кэша
def clear_dns_cache():
    try:
        if platform.system() == "Windows":
            subprocess.run(["ipconfig", "/flushdns"], check=True)
            logging.info("Кэш DNS очищен.")
        elif platform.system() == "Darwin":
            subprocess.run(["sudo", "dscacheutil", "-flushcache"], check=True)
            subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"], check=True)
            logging.info("Кэш DNS очищен.")
        elif platform.system() == "Linux":
            subprocess.run(["sudo", "systemd-resolve", "--flush-caches"], check=True)
            logging.info("Кэш DNS очищен.")
    except Exception as e:
        logging.error(f"Ошибка при очистке кэша DNS: {e}")


# Установка системного прокси
def set_system_proxy(proxy):
    if not is_valid_proxy(proxy):
        logging.error(f"Некорректный формат прокси: {proxy}")
        return

    if "@" in proxy:
        auth, proxy_url = proxy.split("@", 1)
        proxy = f"http://{proxy_url}"
    else:
        auth = None

    ip, port = proxy.split("://")[1].split(":")
    system = platform.system()
    try:
        if system == "Windows":
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            key = winreg.OpenKey(registry, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings", 0,
                                 winreg.KEY_WRITE)
            winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, f"{ip}:{port}")
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в Windows.")
        elif system == "Darwin":
            subprocess.run(["networksetup", "-setwebproxy", "Wi-Fi", ip, port], check=True)
            subprocess.run(["networksetup", "-setsecurewebproxy", "Wi-Fi", ip, port], check=True)
            subprocess.run(["networksetup", "-setproxybypassdomains", "Wi-Fi", NO_PROXY_SITE], check=True)
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в macOS.")
        elif system == "Linux":
            os.environ["http_proxy"] = f"{proxy}"
            os.environ["https_proxy"] = f"{proxy}"
            os.environ["no_proxy"] = NO_PROXY_SITE
            clear_dns_cache()
            logging.info(f"Прокси {proxy} установлен в Linux.")
    except Exception as e:
        logging.error(f"Ошибка при настройке прокси: {e}")


# Запуск Google Chrome с прокси
def launch_chrome_with_proxy(proxy):
    ip, port = proxy.split("://")[1].split(":")
    chrome_path = {
        "Windows": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
        "Darwin": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "Linux": "/usr/bin/google-chrome"
    }.get(platform.system())
    if not chrome_path or not os.path.exists(chrome_path):
        logging.error("Google Chrome не найден.")
        return
    try:
        subprocess.Popen([chrome_path, f"--proxy-server={proxy}", f"--proxy-bypass-list={NO_PROXY_SITE}"])
        logging.info(f"Google Chrome запущен с прокси {proxy}.")
    except Exception as e:
        logging.error(f"Ошибка при запуске Google Chrome: {e}")


# Отключение системного прокси
def disable_system_proxy():
    system = platform.system()
    try:
        if system == "Windows":
            registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
            key = winreg.OpenKey(registry, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings", 0,
                                 winreg.KEY_WRITE)
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            logging.info("Прокси отключен в Windows.")
        elif system == "Darwin":
            subprocess.run(["networksetup", "-setwebproxystate", "Wi-Fi", "off"], check=True)
            subprocess.run(["networksetup", "-setsecurewebproxystate", "Wi-Fi", "off"], check=True)
            logging.info("Прокси отключен в macOS.")
        elif system == "Linux":
            os.environ.pop("http_proxy", None)
            os.environ.pop("https_proxy", None)
            os.environ.pop("no_proxy", None)
            logging.info("Прокси отключен в Linux.")
    except Exception as e:
        logging.error(f"Ошибка при отключении прокси: {e}")


# Обработчик сигналов завершения программы
def signal_handler(sig, frame):
    logging.info("Завершение программы...")
    disable_system_proxy()
    sys.exit(0)


# GUI с tkinter
def gui_interface():
    root = tk.Tk()
    root.title("Proxy Manager")
    root.geometry("400x300")

    def start_script():
        asyncio.run(main())
        messagebox.showinfo("Info", "Скрипт запущен!")

    def update_sources():
        new_source = source_entry.get()
        if is_valid_url(new_source):
            sources = load_proxy_sources()
            sources.append(new_source)
            save_proxy_sources(sources)
            messagebox.showinfo("Success", "Источник добавлен!")
        else:
            messagebox.showerror("Error", "Некорректный URL!")

    tk.Label(root, text="Управление прокси").pack(pady=10)
    tk.Button(root, text="Запустить поиск прокси", command=start_script).pack(pady=5)
    tk.Label(root, text="Добавить источник прокси:").pack()
    source_entry = tk.Entry(root, width=40)
    source_entry.pack()
    tk.Button(root, text="Сохранить источник", command=update_sources).pack(pady=5)
    stats_label = tk.Label(root, text="Статистика: ожидание данных...")
    stats_label.pack(pady=10)

    def update_stats():
        stats_label.config(
            text=f"Всего: {stats['total']}, Рабочих: {stats['working']}, Средняя скорость: {stats['avg_speed']:.2f} сек")
        root.after(1000, update_stats)

    update_stats()
    root.mainloop()


# Основной цикл работы
async def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    proxy_sources = load_proxy_sources()
    global working_proxies

    asyncio.create_task(periodic_proxy_check())
    asyncio.create_task(rotate_proxies_periodically())

    while True:
        logging.info("Поиск рабочих прокси...")
        async with aiohttp.ClientSession() as session:
            tasks = [fetch_proxies(session, url) for url in proxy_sources]
            results = await asyncio.gather(*tasks)
            proxies = list(set(proxy for sublist in results for proxy in sublist if proxy not in blacklisted_proxies))
            if proxies:
                logging.info(f"Найдено {len(proxies)} прокси.")
                working_proxies = await find_working_proxies(proxies)
                if working_proxies:
                    for proxy in working_proxies:
                        anonymity = await check_proxy_anonymity(proxy)
                        speed = await check_proxy_speed(proxy)
                        log_proxy_stats(proxy, speed, anonymity)
                        logging.info(f"Найден рабочий прокси: {proxy}, Анонимность: {anonymity}, Скорость: {speed:.2f}s")
                        set_system_proxy(proxy)
                        launch_chrome_with_proxy(proxy)  # Запуск Chrome с новым прокси
                else:
                    logging.warning("Рабочий прокси не найден. Повторная попытка через 1 минуту...")
            else:
                logging.error("Не удалось получить список прокси. Повторная попытка через 1 минуту...")
            await asyncio.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    try:
        gui_interface()  # Запуск GUI
    except Exception as e:
        logging.error(f"Критическая ошибка: {e}")
        disable_system_proxy()
        sys.exit(1)